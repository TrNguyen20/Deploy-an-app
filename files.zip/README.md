# MES MVP — Code mau di kem bai giang

3 file nay tuong ung dung voi noi dung bai giang "Xay dung he thong MES co ban":

| File | Ung voi phan nao trong bai giang |
|---|---|
| `schema.sql` | Phan 3 — thiet ke 3 bang: `orders`, `production_plan`, `production_actual` (slide 13) |
| `crud.py` | Phan 4 — ket noi MySQL + 4 thao tac CRUD (slide 16-17) |
| `app.py` | Phan 5 — giao dien Streamlit voi 3 chuc nang: Nhap lieu / Xem trang thai / Bao cao (slide 12, 20-22) |

## Cai dat (Phan 4, slide 15)

1. Cai MySQL Server + MySQL Workbench (neu chua co).
2. Tao database va bang bang cach chay file schema:
   ```
   mysql -u root -p < schema.sql
   ```
   (File nay tu tao database `mes_mvp`, 3 bang, va vai dong du lieu mau de test.)
3. Tao mot user rieng cho ung dung (khuyen nghi, thay vi dung root):
   ```sql
   CREATE USER 'mes_user'@'localhost' IDENTIFIED BY 'CHANGE_ME';
   GRANT ALL PRIVILEGES ON mes_mvp.* TO 'mes_user'@'localhost';
   FLUSH PRIVILEGES;
   ```
4. Cai thu vien Python:
   ```
   pip install -r requirements.txt
   ```
5. Mo `crud.py`, sua `DB_CONFIG` cho dung voi user/password ban vua tao —
   hoac dat bien moi truong thay vi sua truc tiep trong code:
   ```
   export MES_DB_USER=mes_user
   export MES_DB_PASSWORD=CHANGE_ME
   ```

## Chay ung dung (Phan 6, slide 25)

```
streamlit run app.py
```

Streamlit se tu mo ung dung tren trinh duyet (mac dinh http://localhost:8501).

## Luu y bao mat

- Khong commit password that vao Git — dung bien moi truong hoac `st.secrets` cua Streamlit.
- File `schema.sql` chi danh cho moi truong hoc/test noi bo, chua co phan quyen nguoi dung
  (dung voi gioi han cua MVP da neu o Phan 7 cua bai giang).
