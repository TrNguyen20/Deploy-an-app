"""
app.py
Giao dien Streamlit cho MES MVP - di kem bai giang "Xay dung he thong MES co ban".
Chay bang lenh:  streamlit run app.py

Luong hoat dong (giong slide 22 trong bai giang):
    Streamlit UI  ->  Ham Python trong crud.py (CRUD)  ->  MySQL Database
"""

import streamlit as st
import pandas as pd
import plotly.express as px

import crud

st.set_page_config(page_title="MES MVP - DYNAMO", layout="wide")
st.title("MES MVP — Theo doi tien do san xuat")

menu = st.sidebar.radio("Chuc nang", ["Nhap lieu", "Xem trang thai", "Bao cao"])

# ---------- 1. NHAP LIEU (slide 12, 20) ----------
if menu == "Nhap lieu":
    st.subheader("Tao don hang moi")
    with st.form("form_new_order"):
        col1, col2, col3 = st.columns(3)
        product_name = col1.text_input("Ten san pham")
        plan_qty = col2.number_input("So luong ke hoach (Plan)", min_value=1, step=1)
        plan_date = col3.date_input("Ngay du kien")
        submitted = st.form_submit_button("Tao don hang")
        if submitted:
            if product_name.strip() == "":
                st.warning("Vui long nhap ten san pham.")
            else:
                order_id = crud.create_order(product_name, int(plan_qty))
                crud.set_plan(order_id, int(plan_qty), str(plan_date))
                st.success(f"Da tao don hang #{order_id} — {product_name}")

    st.divider()

    st.subheader("Cap nhat san luong thuc te (Actual)")
    orders = crud.get_orders()
    if not orders:
        st.info("Chua co don hang nao — hay tao don hang o tren truoc.")
    else:
        order_map = {f"#{o['order_id']} — {o['product_name']}": o["order_id"] for o in orders}
        with st.form("form_update_actual"):
            selected_label = st.selectbox("Chon don hang", list(order_map.keys()))
            actual_qty = st.number_input("So luong thuc te vua san xuat", min_value=0, step=1)
            confirm = st.form_submit_button("Xac nhan")
            if confirm:
                crud.update_actual(order_map[selected_label], int(actual_qty))
                st.success("Da cap nhat san luong thuc te.")

# ---------- 2. XEM TRANG THAI (slide 12) ----------
elif menu == "Xem trang thai":
    st.subheader("Trang thai tien do theo don hang")
    report = crud.get_report()
    if not report:
        st.info("Chua co du lieu de hien thi.")
    else:
        df = pd.DataFrame(report)

        def status_row(pct):
            if pct >= 100:
                return "Hoan thanh"
            elif pct >= 80:
                return "Gan dat tien do"
            else:
                return "Dang cham"

        df["Trang thai"] = df["percent_done"].apply(status_row)
        df = df.rename(columns={
            "order_id": "Order ID", "product_name": "San pham",
            "plan_qty": "Plan", "actual_qty": "Actual", "percent_done": "% Hoan thanh",
        })
        st.dataframe(df, use_container_width=True, hide_index=True)

# ---------- 3. BAO CAO (slide 12, 21) ----------
else:
    st.subheader("Bieu do Plan vs Actual")
    report = crud.get_report()
    if not report:
        st.info("Chua co du lieu de ve bieu do.")
    else:
        df = pd.DataFrame(report)
        df["label"] = "DH-" + df["order_id"].astype(str).str.zfill(2)
        chart_df = df.melt(
            id_vars="label", value_vars=["plan_qty", "actual_qty"],
            var_name="Loai", value_name="So luong",
        )
        chart_df["Loai"] = chart_df["Loai"].map({"plan_qty": "Plan", "actual_qty": "Actual"})
        fig = px.bar(
            chart_df, x="label", y="So luong", color="Loai", barmode="group",
            text="So luong", color_discrete_map={"Plan": "#CADCFC", "Actual": "#1E2761"},
        )
        fig.update_layout(xaxis_title="", legend_title="")
        st.plotly_chart(fig, use_container_width=True)
