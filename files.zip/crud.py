"""
crud.py
Cac ham CRUD (Create, Read, Update) thao tac voi database MySQL.
Di kem bai giang "Xay dung he thong MES co ban" - Phan 4 (slide 16-17).

Truoc khi chay: sua DB_CONFIG ben duoi cho dung voi MySQL Server cua ban,
hoac dat cac bien moi truong MES_DB_HOST / MES_DB_USER / MES_DB_PASSWORD / MES_DB_NAME.
"""

import os
import mysql.connector

DB_CONFIG = {
    "host": os.environ.get("MES_DB_HOST", "localhost"),
    "user": os.environ.get("MES_DB_USER", "mes_user"),
    "password": os.environ.get("MES_DB_PASSWORD", "CHANGE_ME"),
    "database": os.environ.get("MES_DB_NAME", "mes_mvp"),
}


def get_connection():
    """Mo mot ket noi moi toi MySQL. Goi lai ham nay moi khi can thao tac DB."""
    return mysql.connector.connect(**DB_CONFIG)


# ---------- ORDERS ----------

def create_order(product_name, quantity_total):
    """Tao don hang moi, tra ve order_id vua tao."""
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO orders (product_name, quantity_total) VALUES (%s, %s)",
            (product_name, quantity_total),
        )
        conn.commit()
        return cursor.lastrowid
    finally:
        conn.close()


def get_orders():
    """Lay danh sach tat ca don hang."""
    conn = get_connection()
    try:
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM orders ORDER BY order_id")
        return cursor.fetchall()
    finally:
        conn.close()


# ---------- PRODUCTION PLAN ----------

def set_plan(order_id, plan_qty, plan_date):
    """Ghi nhan ke hoach san xuat cho mot don hang (1 dong Plan / don hang)."""
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO production_plan (order_id, plan_qty, plan_date) VALUES (%s, %s, %s)",
            (order_id, plan_qty, plan_date),
        )
        conn.commit()
    finally:
        conn.close()


# ---------- PRODUCTION ACTUAL ----------

def update_actual(order_id, actual_qty):
    """Ghi nhan mot dong san luong thuc te moi cho don hang (giong slide 17)."""
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO production_actual (order_id, actual_qty) VALUES (%s, %s)",
            (order_id, actual_qty),
        )
        conn.commit()
    finally:
        conn.close()


# ---------- BAO CAO: JOIN Plan vs Actual (slide 14) ----------

def get_report():
    """
    So sanh Plan vs Actual moi nhat cho tung don hang.
    Actual lay gia tri moi nhat (theo updated_at) cho moi order_id.
    """
    conn = get_connection()
    try:
        cursor = conn.cursor(dictionary=True)
        cursor.execute(
            """
            SELECT
                o.order_id,
                o.product_name,
                p.plan_qty,
                COALESCE(a.actual_qty, 0) AS actual_qty,
                ROUND(COALESCE(a.actual_qty, 0) / p.plan_qty * 100, 1) AS percent_done
            FROM orders o
            JOIN production_plan p ON p.order_id = o.order_id
            LEFT JOIN (
                SELECT pa1.order_id, pa1.actual_qty
                FROM production_actual pa1
                INNER JOIN (
                    SELECT order_id, MAX(updated_at) AS latest
                    FROM production_actual
                    GROUP BY order_id
                ) pa2 ON pa1.order_id = pa2.order_id AND pa1.updated_at = pa2.latest
            ) a ON a.order_id = o.order_id
            ORDER BY o.order_id
            """
        )
        return cursor.fetchall()
    finally:
        conn.close()
