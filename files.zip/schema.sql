-- schema.sql
-- Cau truc database cho MES MVP (di kem bai giang "Xay dung he thong MES co ban")
-- Chay trong MySQL Workbench, hoac tu terminal:  mysql -u root -p < schema.sql

CREATE DATABASE IF NOT EXISTS mes_mvp
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE mes_mvp;

-- Bang 1: don hang
CREATE TABLE orders (
    order_id        INT AUTO_INCREMENT PRIMARY KEY,
    product_name    VARCHAR(255) NOT NULL,
    quantity_total  INT NOT NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Bang 2: ke hoach san xuat (Plan) - 1 dong / don hang
CREATE TABLE production_plan (
    plan_id     INT AUTO_INCREMENT PRIMARY KEY,
    order_id    INT NOT NULL,
    plan_qty    INT NOT NULL,
    plan_date   DATE NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
);

-- Bang 3: san luong thuc te (Actual) - nhieu dong / don hang, cap nhat theo thoi gian
CREATE TABLE production_actual (
    actual_id   INT AUTO_INCREMENT PRIMARY KEY,
    order_id    INT NOT NULL,
    actual_qty  INT NOT NULL,
    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
);

-- Du lieu mau de test nhanh - khop voi bieu do minh hoa trong bai giang (slide 21)
INSERT INTO orders (product_name, quantity_total) VALUES
    ('Truc banh rang A1', 400),
    ('Khung do B2',       350),
    ('Bac lot C3',        500),
    ('Truc vit D4',       300);

INSERT INTO production_plan (order_id, plan_qty, plan_date) VALUES
    (1, 400, CURDATE()),
    (2, 350, CURDATE()),
    (3, 500, CURDATE()),
    (4, 300, CURDATE());

INSERT INTO production_actual (order_id, actual_qty) VALUES
    (1, 320),
    (2, 350),
    (3, 410),
    (4, 300);
